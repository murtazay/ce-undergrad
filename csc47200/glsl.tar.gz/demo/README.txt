Computer Graphics Homework (Fall 2015) 
Qt Version: Qt5.4.2

Written by: 
Murtaza Yaqoob
Lukas Rascius
Ethan Graber